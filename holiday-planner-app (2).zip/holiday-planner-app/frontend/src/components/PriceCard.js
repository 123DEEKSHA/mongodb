const PriceCard = () => {
  return (
    <div className="prices">
      <h3>Price breakdown:</h3>
    </div>
  );
};

export default PriceCard;
